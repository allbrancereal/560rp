


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 12;

PROPERTY.Name = "Uptown Top Studio";
PROPERTY.Category = "Home";
PROPERTY.Description = "Highest quality fridges for you.";

PROPERTY.Mat	= 'UptownStudioApt';
PROPERTY.Cost = 7500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 635 , Vector(-1339.9899902344, -3994, 454.01000976563), '*47', 'name' },


					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);