


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 38;

PROPERTY.Name = "Downtown Garage";
PROPERTY.Category = "Home";
PROPERTY.Description = "Serves its purpose.";

PROPERTY.Mat	= 'DowntownGarage';
PROPERTY.Cost = 4500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 710 , Vector(-926, 96, 52), '*50', 'name' },
{Index = 709 , Vector(-927, -317, 54.281299591064), 'models/props_c17/door01_left.mdl', 'name' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);