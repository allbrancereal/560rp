


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 4;

PROPERTY.Name = "Schuber Apartment #2";
PROPERTY.Category = "Home";
PROPERTY.Description = "A little on the dull side.";
PROPERTY.Mat	= 'SchuberApartments';

PROPERTY.Cost = 2000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 700 , Vector(-3145, -2532, 310), 'models/props_c17/door01_left.mdl', 'name' },



					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);