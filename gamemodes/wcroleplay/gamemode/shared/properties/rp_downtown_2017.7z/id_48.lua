


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 48;

PROPERTY.Name = "Beach Villa #2";
PROPERTY.Category = "Home";
PROPERTY.Description = "Even more fancy the further down we go.";

PROPERTY.Mat	= 'Beach02';
PROPERTY.Cost = 22500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 1089 , Vector(-4464, -9818, 262), '*128', 'name' },
{Index = 1095 , Vector(-4652, -9700, 208.38000488281), '*131', 'name' },
{Index = 1081 , Vector(-4696, -9123, 207), '*125', 'name' },
{Index = 1088 , Vector(-4588, -9492, 208.38000488281), '*127', 'name' },
{Index = 1082 , Vector(-4471, -9702, 345), '*126', 'name' },
{Index = 1091 , Vector(-4820, -9644, 336.38000488281), '*129', 'name' },
{Index = 1093 , Vector(-4936, -9332, 336.38000488281), '*130', 'name' },


					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);