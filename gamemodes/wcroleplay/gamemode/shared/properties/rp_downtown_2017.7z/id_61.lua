


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 61;

PROPERTY.Name = "Springer Apartment #1";
PROPERTY.Category = "Home";
PROPERTY.Description = "Cozy at first.";
PROPERTY.Mat	= 'SpringerApartments';

PROPERTY.Cost = 6000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 845 , Vector(-1919, -2664, 201), '*77', 'name' },
{Index = 850 , Vector(-1940, -2262, 190), '*82', 'name' },



					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);