


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 44;

PROPERTY.Name = "Back End Industrial Warehouse";
PROPERTY.Category = "Business";
PROPERTY.Description = "It's quite small, not worth.";

PROPERTY.Mat	= 'BackEndInd';
PROPERTY.Cost = 7000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 1160 , Vector(84, 4344.5, 102), '*140', 'name' },
{Index = 1159 , Vector(-91, 4337, 94.281303405762), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 1161 , Vector(375, 5185, 30.281299591064), 'models/props_c17/door01_left.mdl', 'name' },


					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);