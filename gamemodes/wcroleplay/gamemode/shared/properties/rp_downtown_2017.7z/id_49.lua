


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 49;

PROPERTY.Name = "Beach Villa #3";
PROPERTY.Category = "Home";
PROPERTY.Description = "Even more expensive?";

PROPERTY.Mat	= 'Beach03';
PROPERTY.Cost = 27500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 1061 , Vector(-5312, -9818, 262), '*121', 'name' },
{Index = 1067 , Vector(-5500, -9700, 208.38000488281), '*124', 'name' },
{Index = 1054 , Vector(-5319, -9702, 345), '*119', 'name' },
{Index = 1053 , Vector(-5544, -9123, 207), '*118', 'name' },
{Index = 1060 , Vector(-5436, -9492, 208.38000488281), '*120', 'name' },
{Index = 1065 , Vector(-5784, -9332, 336.38000488281), '*123', 'name' },
{Index = 1063 , Vector(-5668, -9644, 336.38000488281), '*122', 'name' },


					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);