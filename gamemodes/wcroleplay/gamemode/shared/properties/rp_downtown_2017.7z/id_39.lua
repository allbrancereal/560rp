


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 39;

PROPERTY.Name = "Industrial MTL";
PROPERTY.Category = "Business";
PROPERTY.Description = "Quite the structure, holds loads of stuff.";

PROPERTY.Mat	= 'IndMTL';
PROPERTY.Cost = 22500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 495 , Vector(349, 1958, 54), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 493 , Vector(345.5, 2258, 94), '*35', 'name' },
{Index = 494 , Vector(345.5, 2492, 94), '*36', 'name' },
{Index = 755 , Vector(-393, 1897, 54.281299591064), 'models/props_c17/door01_left.mdl', 'name' },


					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);