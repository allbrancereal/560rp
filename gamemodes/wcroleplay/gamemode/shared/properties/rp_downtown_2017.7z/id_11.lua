


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 11;

PROPERTY.Name = "Uptown Studio #2";
PROPERTY.Category = "Home";
PROPERTY.Description = "When you are that high you don't really care about money.";
PROPERTY.Mat	= 'UptownStudioApt';
PROPERTY.Cost = 6000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 632 , Vector(-1339.9899902344, -3994, 318.01000976563), '*46', 'name' },


					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);