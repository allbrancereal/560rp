


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 41;

PROPERTY.Name = "Industrial Garage";
PROPERTY.Category = "Business";
PROPERTY.Description = "It's quite tall.";

PROPERTY.Mat	= 'IndustrialGarage';
PROPERTY.Cost = 32000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 642 , Vector(1438, 808, 64), '*48', 'name' },
{Index = 643 , Vector(1285, 3143, 54), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 640 , Vector(1561, 3189, 86), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 639 , Vector(1607, 3195, 214), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 641 , Vector(1527, 3195, 214), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 638 , Vector(1607, 3195, 342), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 637 , Vector(1607, 3195, 470), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 644 , Vector(1547, 3097, 470), 'models/props_c17/door01_left.mdl', 'name' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);