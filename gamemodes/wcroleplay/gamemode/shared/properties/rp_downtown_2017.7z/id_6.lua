


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 6;

PROPERTY.Name = "Moon Suite";
PROPERTY.Category = "Home";
PROPERTY.Description = "Enclosed but designer.";
PROPERTY.Mat	= 'MoonSuite';

PROPERTY.Cost = 2250;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 718 , Vector(-2411, -2783, 54.281200408936), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 717 , Vector(-2317, -2783, 54.281200408936), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 719 , Vector(-2653, -2496.9099121094, 53.999599456787), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 720 , Vector(-2893, -2496.9099121094, 53.999599456787), 'models/props_c17/door01_left.mdl', 'name' },


					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);