


local PROPERTY = PROPERTY ||{};

PROPERTY.ID =42 ;

PROPERTY.Name = "Burger King";
PROPERTY.Category = "Business";
PROPERTY.Description = "Have it your way.";

PROPERTY.Mat	= 'BurgerKing';
PROPERTY.Cost = 9000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 609 , Vector(-386.01000976563, 586, 54), '*40', 'name' },


					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);