


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 16;

PROPERTY.Name = "Fountain Studio #1";
PROPERTY.Category = "Home";
PROPERTY.Description = "Super fancy and spacy.";

PROPERTY.Mat	= 'FTStudio1';
PROPERTY.Cost = 10000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 481 , Vector(-830, -3446, 54), '*34', 'name' },



					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);