


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 52;

PROPERTY.Name = "Kell Co.";
PROPERTY.Category = "Business";
PROPERTY.Description = "Super horrible. Wow";

PROPERTY.Mat	= 'IndigoApartments';
PROPERTY.Cost = 6000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 771 , Vector(1549.9899902344, 2093.0100097656, 88.5), '*62', 'name' },
{Index = 772 , Vector(1701.9899902344, 2093.0100097656, 88.5), '*63', 'name' },



					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);