


local PROPERTY = PROPERTY ||{};

PROPERTY.ID =54 ;
 
PROPERTY.Name = "Indigo Apartment #4";
PROPERTY.Category = "Home";
PROPERTY.Description = "Quite luxurious because of the height.";

PROPERTY.Mat	= 'IndigoApartments';
PROPERTY.Cost = 8000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 940 , Vector(-2350, -4011.9899902344, 614.01000976563), '*96', 'name' },
{Index = 946 , Vector(-2972, -3865, 623), '*100', 'name' },


					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);