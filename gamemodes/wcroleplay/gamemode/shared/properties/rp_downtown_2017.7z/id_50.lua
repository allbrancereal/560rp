


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 50;

PROPERTY.Name = "Beach Villa #4";
PROPERTY.Category = "Home";
PROPERTY.Description = "Shitty View";

PROPERTY.Mat	= 'Beach04';
PROPERTY.Cost = 25000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 1026 , Vector(-6376, -9123, 207), '*117', 'name' },
{Index = 1018 , Vector(-6268, -9492, 208.38000488281), '*115', 'name' },
{Index = 1017 , Vector(-6144, -9818, 262), '*114', 'name' },
{Index = 1011 , Vector(-6332, -9700, 208.38000488281), '*111', 'name' },
{Index = 1015 , Vector(-6500, -9644, 336.38000488281), '*113', 'name' },
{Index = 1013 , Vector(-6616, -9332, 336.38000488281), '*112', 'name' },
{Index = 1025 , Vector(-6151, -9702, 345), '*116', 'name' },



					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);