


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 2;

PROPERTY.Name = "Happy-Go Lucky";
PROPERTY.Category = "Home";
PROPERTY.Description = "A fancy house.";
PROPERTY.Mat	= 'HappyGoLucky';

PROPERTY.Cost = 5000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 696 , Vector(-2407, -2009, 118.28099822998), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 697 , Vector(-2675, -2185, 118.28099822998), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 695 , Vector(-2434, -2265, -74), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 693 , Vector(-2503, -2002, -74), 'models/props_c17/door01_left.mdl', 'name' },
{Index = 1173 , Vector(-2318, -2336, -2.039999961853), '*144', 'name' },


					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);