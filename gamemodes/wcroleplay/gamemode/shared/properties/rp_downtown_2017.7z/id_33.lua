


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 33;

PROPERTY.Name = "Downtown Suit #1";
PROPERTY.Category = "Home";
PROPERTY.Description = "Really bad but if you got no money what are you gonna do?";

PROPERTY.Mat	= 'DowntownSuit';
PROPERTY.Cost = 1500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 863 , Vector(172, -532, 192), '*83', 'name' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);