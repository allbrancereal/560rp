


local PROPERTY = PROPERTY ||{};

PROPERTY.ID = 47;

PROPERTY.Name = "Beach Villa #1";
PROPERTY.Category = "Home";
PROPERTY.Description = "Super fancy, 10/10";

PROPERTY.Mat	= 'Beach01';
PROPERTY.Cost = 20000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{
{Index = 1116 , Vector(-3724, -9492, 208.38000488281), '*134', 'name' },
{Index = 1117 , Vector(-3600, -9818, 262), '*135', 'name' },
{Index = 1123 , Vector(-3788, -9700, 208.38000488281), '*138', 'name' },
{Index = 1109 , Vector(-3832, -9123, 207), '*132', 'name' },
{Index = 1121 , Vector(-4072, -9332, 336.38000488281), '*137', 'name' },
{Index = 1119 , Vector(-3956, -9644, 336.38000488281), '*136', 'name' },
{Index = 1110 , Vector(-3607, -9702, 345), '*133', 'name' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true; // No Restrictions

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else // You couldn't buy it!
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end;


SetupProperty(PROPERTY);