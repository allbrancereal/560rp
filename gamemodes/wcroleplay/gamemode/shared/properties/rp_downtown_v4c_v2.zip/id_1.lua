//print("New Properties Loaded")


local PROPERTY = {};

PROPERTY.ID = 1;
 
PROPERTY.Name = "Foundainside Store";
PROPERTY.Category = "Business";
PROPERTY.Description = "A small store with two rooms and a window.";
PROPERTY.Mat	= 'fountainsidestore';

PROPERTY.Cost = 1650;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 

			{ Index = 2308 ,Vector(-1219, -2436, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
			{ Index = 2495 ,Vector(-1618, -2796, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
			{ Index = 2496 ,Vector(-1354, -2937, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY );

/*

local PROPERTY = {};

PROPERTY.ID = ;
 
PROPERTY.Name = "";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= '';

PROPERTY.Cost = 1650;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

*/

local PROPERTY = {};

PROPERTY.ID = 2;
 
PROPERTY.Name = "Fountainside Apartment #1";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "A nice apartment with a room.";
PROPERTY.Mat	= 'fountainsideapartments';

PROPERTY.Cost = 600;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1469 ,Vector(-872, -2086, -14), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1502 ,Vector(-1034, -2242, -14), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 3;
 
PROPERTY.Name = "Fountainside Apartment #2";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "An apartment beside the first, with a closet on the mirroring side.";
PROPERTY.Mat	= 'fountainsideapartments';

PROPERTY.Cost = 600;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1470 ,Vector(-872, -1702, -14), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1479 ,Vector(-1034, -1672, -14), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 4;
 
PROPERTY.Name = "Fountainside Apartment #3";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "Identical to the second apartment, but higher up.";
PROPERTY.Mat	= 'fountainsideapartments';

PROPERTY.Cost = 750;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1453 ,Vector(-872, -1702, 114), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1480 ,Vector(-1034, -1672, 114), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 5;
 
PROPERTY.Name = "Fountainside Apartment #4";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "Identical to fountainside apartment #1 but higher up!";
PROPERTY.Mat	= 'fountainsideapartments';

PROPERTY.Cost = 750;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1504 ,Vector(-1034, -2242, 114), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1454 ,Vector(-872, -1958, 114), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);



local PROPERTY = {};

PROPERTY.ID = 6;
 
PROPERTY.Name = "Hotel Janitor Room";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "A silly room within the hotel.";
PROPERTY.Mat	= 'hotel';

PROPERTY.Cost = 1035;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1430 ,Vector(-818, -1363, -142), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end 
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);



local PROPERTY = {};

PROPERTY.ID = 7;
 
PROPERTY.Name = "Hotel Apartment #1";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "A swell apartment with an extra room!";
PROPERTY.Mat	= 'hotel';

PROPERTY.Cost = 1650;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1416 ,Vector(-810, -1300, -5.7186999320984), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1394 ,Vector(-749, -1226, -40), '*22', '' },
{ Index = 1393 ,Vector(-749, -1282, -40), '*21', '' },
{ Index = 2468 ,Vector(-883, -1005, -5.71875), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2466 ,Vector(-1028, -1303, -5.7187600135803), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);



local PROPERTY = {};

PROPERTY.ID = 8;
 
PROPERTY.Name = "Hotel Apartment #2";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "An apartment alike to the hotel apartment #1 , just higher up.";
PROPERTY.Mat	= 'hotel';

PROPERTY.Cost = 1035;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1415 ,Vector(-810, -1303, 122), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1400 ,Vector(-749, -1282, 88), '*23', '' },
{ Index = 1401 ,Vector(-749, -1226, 88), '*24', '' },
{ Index = 2241 ,Vector(-1028, -1303, 122), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2467 ,Vector(-883, -1005, 122), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);



local PROPERTY = {};

PROPERTY.ID = 9;
 
PROPERTY.Name = "Hotel Apartment #3";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "This apartment has 1 room less than #1 & #2 but is more expensive.";
PROPERTY.Mat	= 'hotel';

PROPERTY.Cost = 1200;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1409 ,Vector(-882.9990234375, -1005, 250), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1611 ,Vector(-749, -1282, 216), '*74', '' },
{ Index = 1404 ,Vector(-749, -1226, 216), '*25', '' },
{ Index = 1414 ,Vector(-810, -1303, 250), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);



local PROPERTY = {};

PROPERTY.ID = 10;
 
PROPERTY.Name = "Hotel Penthouse";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "A pristine apartment connecting multiple buildings.";
PROPERTY.Mat	= 'hotel';

PROPERTY.Cost = 4350;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1417 ,Vector(-810, -1303, 378), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1537 ,Vector(-798, -920.15002441406, 378), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1420 ,Vector(-749, -942, 344), '*28', '' },
{ Index = 1421 ,Vector(-749, -998, 344), '*29', '' },
{ Index = 1419 ,Vector(-749, -1282, 344), '*27', '' },
{ Index = 1418 ,Vector(-749, -1226, 344), '*26', '' },
{ Index = 1422 ,Vector(-853, -941, 506), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2464 ,Vector(-853, -1133, 506.28100585938), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 11;
 
PROPERTY.Name = "Downtown Overview";
PROPERTY.Category = "House";
PROPERTY.Description = "A house built on top of the bank providing a great view.";
PROPERTY.Mat	= 'downtownoverview';

PROPERTY.Cost = 6200;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2109 ,Vector(-1706.3499755859, -302.43798828125, 13), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2211 ,Vector(-1802, -180, 13.281299591064), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2114 ,Vector(-2068.3500976563, -222.43800354004, 13), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2113 ,Vector(-1726.3499755859, -216.43800354004, 141), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2126 ,Vector(-1874.3499755859, -210.43800354004, 285), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 12;
 
PROPERTY.Name = "The Cafe";
PROPERTY.Category = "Business";
PROPERTY.Description = "A Three-Storey building with a topside door.";
PROPERTY.Mat	= 'hotel';

PROPERTY.Cost = 2800;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1383 ,Vector(-1005.9299926758, 308.36401367188, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1623 ,Vector(-842, 87, 250), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 13;
 
PROPERTY.Name = "Parker Building";
PROPERTY.Category = "Business";
PROPERTY.Description = "A garage beside the PD, allowing quick access to some security.";
PROPERTY.Mat	= 'parkerbuilding';

PROPERTY.Cost = 4500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1297 ,Vector(-1441.9100341797, 428, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1296 ,Vector(-1441.9100341797, 522, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1435 ,Vector(-1439.5, 653, -102), '*30', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 14;
 
PROPERTY.Name = "Marr Freight Co. Warehouse";
PROPERTY.Category = "Business";
PROPERTY.Description = "A warehouse sold off for office space.";
PROPERTY.Mat	= 'marrfreight';

PROPERTY.Cost = 7725;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1538 ,Vector(-17, 1519, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1539 ,Vector(-17, 1425, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1372 ,Vector(-96, 1222, -125), '*12', '' },
{ Index = 1373 ,Vector(-200, 1222, -125), '*13', '' },
{ Index = 1303 ,Vector(-269, 1017, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1304 ,Vector(-269, 1111, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1321 ,Vector(-500, 976.5, -78), '*5', '' },
{ Index = 1319 ,Vector(-651, 970, -86), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 15;
 
PROPERTY.Name = "Safe X-Change";
PROPERTY.Category = "Business";
PROPERTY.Description = "A secure building allowing for safe exchanges through a tiny box with two doors.";
PROPERTY.Mat	= 'safexchange';

PROPERTY.Cost = 8250;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1347 ,Vector(497, 1139, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1349 ,Vector(714, 1251.5, -136), '*9', '' },
{ Index = 1382 ,Vector(766, 1251.5, -136), '*20', '' },
{ Index = 1348 ,Vector(837, 1279, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1951 ,Vector(509, 1041, -14), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 16;
 
PROPERTY.Name = "Downtown Bar";
PROPERTY.Category = "Business";
PROPERTY.Description = "A bar with a room storage + upstairs.";
PROPERTY.Mat	= 'dtbar';

PROPERTY.Cost = 2250;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1439 ,Vector(497, 1609, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1438 ,Vector(987, 1543, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1947 ,Vector(923, 1759, 2), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 17;
 
PROPERTY.Name = "Downtown Tiny Shop";
PROPERTY.Category = "Business";
PROPERTY.Description = "A cute shop with a electric window allowing for upfront sales.";
PROPERTY.Mat	= 'downtowntinyshop';

PROPERTY.Cost = 700;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1339 ,Vector(563, 407, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1344 ,Vector(694, 404, -114), '*8', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 18;
 
PROPERTY.Name = "Hideway Storage";
PROPERTY.Category = "Business";
PROPERTY.Description = "A hide-way set of rooms for storage.";
PROPERTY.Mat	= 'hidewaystorage';

PROPERTY.Cost = 4000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2550 ,Vector(150, 215, -145.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2554 ,Vector(78, -92, -145.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2553 ,Vector(428, 170, -145.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 19;
 
PROPERTY.Name = "Veikko Warehouse";
PROPERTY.Category = "Business";
PROPERTY.Description = "An expensive warehouse with tons of space as well as multiple electric gates.";
PROPERTY.Mat	= 'veikko';

PROPERTY.Cost = 9500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1540 ,Vector(-526.5, 3586, -102), '*59', '' },
{ Index = 1541 ,Vector(-526.5, 3820, -102), '*60', '' },
{ Index = 1542 ,Vector(-523, 3286, -142), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 20;
 
PROPERTY.Name = "Office Space";
PROPERTY.Category = "Business";
PROPERTY.Description = "The perfect office, multiple rooms and a upstairs penthouse for private business.";
PROPERTY.Mat	= 'officespace';

PROPERTY.Cost = 14500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1728 ,Vector(917, 2879, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1726 ,Vector(833, 3325, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1723 ,Vector(937, 3439, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1721 ,Vector(913, 3698, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1722 ,Vector(1007, 3698, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1725 ,Vector(1450, 3439, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1727 ,Vector(1461, 3299, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1761 ,Vector(1225, 3013, 14), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1760 ,Vector(1065, 2913, 14), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1775 ,Vector(798, 3388, 14), '*92', '' },
{ Index = 1774 ,Vector(698, 3388, 14), '*91', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 21;
 
PROPERTY.Name = "Office Space Storage";
PROPERTY.Category = "Business";
PROPERTY.Description = "A tiny room allowing for tons of storage.";
PROPERTY.Mat	= 'officespacestorage';

PROPERTY.Cost = 400;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1759 ,Vector(1337, 2653, -142), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 22;
 
PROPERTY.Name = "Ghetto Shop";
PROPERTY.Category = "Business";
PROPERTY.Description = "A shop in the ghetto with a private room.";
PROPERTY.Mat	= 'ghettoshop';

PROPERTY.Cost = 5000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1840 ,Vector(2319, 3443, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1842 ,Vector(2047, 3517, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1841 ,Vector(1795, 3575, -142), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 23;
 
PROPERTY.Name = "Ghetto Warehouse";
PROPERTY.Category = "Business";
PROPERTY.Description = "A spacious warehouse in the ghetto.";
PROPERTY.Mat	= 'ghettowarehouse';

PROPERTY.Cost = 9500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1881 ,Vector(4954.91015625, 3300.7199707031, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1882 ,Vector(4954.91015625, 3206.7199707031, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1891 ,Vector(5112, 3161.9099121094, -142), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 24;
 
PROPERTY.Name = "Ghetto House #1";
PROPERTY.Category = "House";
PROPERTY.Description = "A huge house with a private room as well as balcony.";
PROPERTY.Mat	= 'ghettohouse1';

PROPERTY.Cost = 8400;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1954 ,Vector(3675, 2485, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1960 ,Vector(3511, 2127, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1961 ,Vector(3625, 2127, -8.71875), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1959 ,Vector(3631, 2379, -8.71875), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 25;
 
PROPERTY.Name = "Ghetto House #2";
PROPERTY.Category = "House";
PROPERTY.Description = "A spacious house in the ghetto with an upstairs.";
PROPERTY.Mat	= 'ghettohouse2';

PROPERTY.Cost = 4000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1863 ,Vector(2223, 2709, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1835 ,Vector(1795, 2807, -142), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 26;
 
PROPERTY.Name = "Ghetto Apartment Storage";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= 'ghettoapartments';

PROPERTY.Cost = 250;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1901 ,Vector(3269, 4785, -82), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 27;
 
PROPERTY.Name = "Ghetto Apartment #1";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'ghettoapartments';

PROPERTY.Cost = 450;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1995 ,Vector(2949, 4785, -82), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 28;
 
PROPERTY.Name = "Ghetto Apartment #2";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'ghettoapartments';

PROPERTY.Cost = 450;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1899 ,Vector(2565, 4785, -82), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 29;
 
PROPERTY.Name = "Ghetto Apartment #3";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'ghettoapartments';

PROPERTY.Cost = 450;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1900 ,Vector(2565, 4657, -82), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 30;
 
PROPERTY.Name = "Ghetto Apartment #4";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'ghettoapartments';

PROPERTY.Cost = 450;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1906 ,Vector(3007, 4358, -218), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 31;
 
PROPERTY.Name = "Ghetto Apartment #5";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'ghettoapartments';

PROPERTY.Cost = 450;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1907 ,Vector(3007, 4677, -218), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 32;
 
PROPERTY.Name = "Ghetto Apartment #6";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'ghettoapartments';

PROPERTY.Cost = 450;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1905 ,Vector(3237, 4601, -218), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 33;
 
PROPERTY.Name = "Ghetto Apartments Penthouse";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'ghettoapartments';

PROPERTY.Cost = 1650;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1897 ,Vector(3101, 4812, 54), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1898 ,Vector(2612, 4657, 54), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 34;
 
PROPERTY.Name = "Ghetto House #3";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'ghettohouse3';

PROPERTY.Cost = 3750;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1806 ,Vector(4104.08984375, 3382, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1807 ,Vector(3928.0900878906, 3561, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1808 ,Vector(3928.0900878906, 3372, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1809 ,Vector(3857.0900878906, 3183, -142), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1810 ,Vector(3914, 3457.9099121094, -9), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 35;
 
PROPERTY.Name = "Ghetto Club House";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'ghettohouse4';

PROPERTY.Cost = 532000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;

PROPERTY.Doors = 	{ 

{  RemoveDoor = false,Index = 1355 ,Vector(2315, 382, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{  RemoveDoor = true,Index = 2539 ,Vector(2149, 108, -141.99600219727), 'models/props_c17/door01_left.mdl', '' }, 

					};
					
PROPERTY.ClubHouseInformation = {
	Desc = "A cozy house along a T-Junktion. Perfect for daily operations.";
	EnterLoc = {Vector(2297.692139, 343.692688, -188.273346),Angle(0,-90 ,0.000000)};	
	ExitLoc = {Vector(2297.416748, 438.108093  ,-188.968750),Angle(0,90,0)};	
	Tag = "gch",
	DisplayProps = {
		/*
		{"EntityClass", Vector(Position), Angle(Angle), model,Nocollide};
		*/
		{"fsrpmonitor", Vector(1904.616 , -198.722 , -158.362 ), Angle(0.0 , 0.0 , 0 ),nil, false};
		{"wcrp_ibusinessprop", Vector(1903.08 , -187.73 , -177.316 ), Angle(0.0 , 0.0 , 0 ),"models/props_c17/furnituretable002a.mdl" ,false};
		{"fsrpcomputer", Vector(1916.458 , -236.641 , -195.497 ), Angle(0.0 , 0.0 , 0 ),nil, false};
	};	
}

PROPERTY.OnSold = function( _p ) 

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY,2);

local PROPERTY = {};

PROPERTY.ID = 36;
 
PROPERTY.Name = "Industrial House #1";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'industrialhouse1';

PROPERTY.Cost = 2500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1638 ,Vector(2377, -2263, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 37;
 
PROPERTY.Name = "Industrial House #2";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'industrialhouse2';

PROPERTY.Cost = 2500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1629 ,Vector(2376, -1454, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 38;
 
PROPERTY.Name = "Industrial Storage";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= 'industrialstorage';

PROPERTY.Cost = 1650;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1637 ,Vector(2377, -1639, -142), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 39;
 
PROPERTY.Name = "Suburbs Apartment #1";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'subsapartments';

PROPERTY.Cost = 2650;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2048 ,Vector(-544, -7154, -5.75), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2040 ,Vector(-347, -6816, -5), '*118', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 40;
 
PROPERTY.Name = "Suburbs Apartment #2";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'subsapartments';

PROPERTY.Cost = 2650;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2047 ,Vector(76, -7154, -5.75), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2051 ,Vector(-113, -6816, -5), '*121', '' },
{ Index = 2052 ,Vector(-74, -7020, -5.75), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 41;
 
PROPERTY.Name = "Suburbs Apartment #3";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'subsapartments';

PROPERTY.Cost = 3600;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2045 ,Vector(6, -7020, 130.25), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2046 ,Vector(-192, -7154, 130.25), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2044 ,Vector(-113, -6816, 131), '*120', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 42;
 
PROPERTY.Name = "Suburbs Apartment #4";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'subsapartments';

PROPERTY.Cost = 3600;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2043 ,Vector(-348, -7154, 130.25), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2041 ,Vector(-486, -7024, 130), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2042 ,Vector(-347, -6816, 131), '*119', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 43;
 
PROPERTY.Name = "Suburbs House #1";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'subhouse1';

PROPERTY.Cost = 12500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2073 ,Vector(-913, -5891, -142.43699645996), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2036 ,Vector(-849, -5864, -142.43699645996), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2037 ,Vector(-769, -5653, -142.43699645996), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2038 ,Vector(-595, -5490.8198242188, -143.43699645996), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2034 ,Vector(-871, -5608, -14.437700271606), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2033 ,Vector(-810, -5761, -14.437700271606), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 44;
 
PROPERTY.Name = "Suburbs House #2";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'subhouse2to4';

PROPERTY.Cost = 3000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2023 ,Vector(-1544, -5918.8999023438, -145.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2018 ,Vector(-1525, -5593, -144.71699523926), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 45;
 
PROPERTY.Name = "Suburbs House #3";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'subhouse2to4';

PROPERTY.Cost = 3000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 

{ Index = 2022 ,Vector(-1878, -5918, -145.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2031 ,Vector(-1787, -5593, -145.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 46;
 
PROPERTY.Name = "Suburbs House #4";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'subhouse2to4';

PROPERTY.Cost = 3000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2030 ,Vector(-2140, -5918, -145.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2080 ,Vector(-2081, -5592.1801757813, -144.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 47;
 
PROPERTY.Name = "Suburbs Garage";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= 'subsgarage';

PROPERTY.Cost = 7850;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2029 ,Vector(-2218, -6564, -145.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2081 ,Vector(-1872.5, -6563, -139), '*122', '' },
{ Index = 2039 ,Vector(-1790, -6981.8198242188, -145.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2278 ,Vector(-2221, -6912, -13.718799591064), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 48;
 
PROPERTY.Name = "Suburbs House #5";
PROPERTY.Category = "House";
PROPERTY.Description = "";
PROPERTY.Mat	= 'subhouse5';

PROPERTY.Cost = 1650;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2635 ,Vector(-2354, -7082, -111.71900177002), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2636 ,Vector(-2761, -7043, -111.71900177002), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 49;
 
PROPERTY.Name = "Downtown Storage";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= 'downtownstorage';

PROPERTY.Cost = 1650;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2499 ,Vector(-1818, -2821, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2502 ,Vector(-1818, -3065, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 50;
 
PROPERTY.Name = "Outskirt Warehouse #1";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= 'outskirtwh1';

PROPERTY.Cost = 11000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2547 ,Vector(-3973.0100097656, 1844.0100097656, -142), '*180', '' },
{ Index = 2451 ,Vector(-4444, 2618, -150), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2557 ,Vector(-4508, 1864, -149.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2559 ,Vector(-4384, 1641, -149.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);


local PROPERTY = {};

PROPERTY.ID = 51;
 
PROPERTY.Name = "Outskirt Warehouse #2";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= 'outskirtwh2';

PROPERTY.Cost = 14000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2398 ,Vector(-3973.9899902344, 3280, -142), '*167', '' },
{ Index = 2397 ,Vector(-3971, 3365, -150), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2396 ,Vector(-3973.9899902344, 3496, -142), '*166', '' },
{ Index = 2448 ,Vector(-4590, 3016, -149.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 52;
 
PROPERTY.Name = "Outskirt Warehouse #3";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= 'outskirtwh3';

PROPERTY.Cost = 16000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2434 ,Vector(-3279.9899902344, 2864, -142), '*170', '' },
{ Index = 2390 ,Vector(-3281, 3249, -157.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2388 ,Vector(-3281, 3343, -157.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2439 ,Vector(-2837, 2705, -150), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2436 ,Vector(-2725, 2705, -150), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID =53; 
 
PROPERTY.Name = "Outskirt Apartment";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'outskirtapartment';
  
PROPERTY.Cost = 321500; 
 
PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ RemoveDoor = false,Index = 2417 ,Vector(-3284, 3619, -142), 'models/props_c17/door01_left.mdl', '' },
{ RemoveDoor = true,Index = 2427 ,Vector(-3180, 3872, -17.718799591064), 'models/props_c17/door01_left.mdl', '' },
{ RemoveDoor = true,Index = 2422 ,Vector(-3144, 3591.0900878906, -17.718799591064), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.BusinessInformation = {
	
	Type = 1;	
	Scalar = 1;	
	EnterLoc = {Vector(-3248.429443 ,3648.565918 ,-185.053741),Angle(0,90 ,0.000000)};	
	ExitLoc = {Vector(-3320.818359, 3641.880127 ,-185.968750),Angle(0,180,0)};	
	DisplayProps = {
		/*
		{"EntityClass", Vector(Position), Angle(Angle), model,Nocollide};
		*/
	};	
	Tag = "oskrt",
	BusinessInitIdentifier = "dtstr";
	Upgrades = {
		[1] = {
			Name = "Grow Lights";
			Cost = 384000;
			Description = "Adds extra grow lights to the facility.";
			DisplayProps = {
				//{"EntityClass", Vector(Position), Angle(Angle), InvisibleUntilUpgrade, Nocollide};
			};
			GrowValueIncrease = 25;// % PERCENT
			GrowSpeedIncrease = 10; // % PERCENT
		};
		[2] = {
			Name = "Employee Lounge";
			Cost = 745000;
			Description = "Unlocks the employee lounge, allowing your workers to rest more comfortably.";
			DisplayProps = {
				//{"EntityClass", Vector(Position), Angle(Angle), InvisibleUntilUpgrade, Nocollide};
			};
			GrowValueIncrease = 20;// % PERCENT
			GrowSpeedIncrease = 50; // % PERCENT
		};	
		[3] = {
			Name = "Paid Off Deliveries";
			Cost = 554000;
			Description = "Increases the money you retain when laundering.";
			DisplayProps = {
				//{"EntityClass", Vector(Position), Angle(Angle), InvisibleUntilUpgrade, Nocollide};
			};
			GrowValueIncrease = 50;// % PERCENT
			GrowSpeedIncrease = 0; // % PERCENT
		};
	};
}

PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else  
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY,1);

local PROPERTY = {};

PROPERTY.ID =54;
 
PROPERTY.Name = "Fountainside Warehouse";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= 'fountainsidewarehouse';

PROPERTY.Cost = 7000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2523 ,Vector(-1034.9899902344, -818, -134), '*175', '' },
{ Index = 2633 ,Vector(-1030, -620, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2580 ,Vector(-505, -742, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID =55;
 
PROPERTY.Name = "Backside Apartment";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'marrfreight';

PROPERTY.Cost = 4450;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2512 ,Vector(-888, 1988, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2517 ,Vector(-1001, 1627, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 56;
 
PROPERTY.Name = "The Loft";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'theloft';

PROPERTY.Cost = 6000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2560 ,Vector(1619, 1528, -145.91999816895), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2545 ,Vector(1980, 1510, -145.91999816895), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2544 ,Vector(1980, 1416, -145.91999816895), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2561 ,Vector(1486, 1810, -145.91999816895), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 57;
 
PROPERTY.Name = "Industrial Warehouse #1";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= 'industrial1';

PROPERTY.Cost = 11000;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1579 ,Vector(955, -1487.9100341797, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1580 ,Vector(861, -1487.9100341797, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1974 ,Vector(815.90899658203, -1645, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1607 ,Vector(360.48999023438, -1946, -78), '*72', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 58;
 
PROPERTY.Name = "Industrial Warehouse #2";
PROPERTY.Category = "Business";
PROPERTY.Description = "";
PROPERTY.Mat	= 'industrial2';

PROPERTY.Cost = 12500;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 2598 ,Vector(1004, -358, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2597 ,Vector(910, -358, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },
{ Index = 2599 ,Vector(1058, -306, -141.71899414063), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);

local PROPERTY = {};

PROPERTY.ID = 59;
 
PROPERTY.Name = "Hidden Room";
PROPERTY.Category = "Apartment";
PROPERTY.Description = "";
PROPERTY.Mat	= 'hiddenroom';

PROPERTY.Cost = 1650;

PROPERTY.PrimaryOwner = PROPERTY.PrimaryOwner || nil;
PROPERTY.Doors = 	{ 
{ Index = 1578 ,Vector(-235, -2162, -97), 'models/props_c17/door01_left.mdl', '' },
{ Index = 1704 ,Vector(-326, -2533, -97), 'models/props_c17/door01_left.mdl', '' },

					};
					
PROPERTY.OnSold = function( _p )

	_p:Notify( "You have sold " .. PROPERTY.Name )
	

end;
PROPERTY.CanBuy = function( _p )

	return true;

end; 

PROPERTY.PostCantBuy = function( _p , bool )
	if bool then // You bought it!

	else 
	
	end
end
					
PROPERTY.OnBought = function( _p )

	_p:Notify( "You have bought " .. PROPERTY.Name )


end; 


SetupProperty(PROPERTY);
